package com.fcfm.poi.pia.modelos

class Integrante (
    var id: String = "",
    var nombre: String = ""
)