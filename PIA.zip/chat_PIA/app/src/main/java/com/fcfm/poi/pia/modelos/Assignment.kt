package com.fcfm.poi.pia.modelos

import java.sql.Timestamp

class Assignment (var id: String = "",
                  var titulo: String = "",
                  var instrucciones: String = "",
                  var puntos: Int = 0,
                  var timestamp: FechaAssignment? = null){
}