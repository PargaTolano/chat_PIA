package com.fcfm.poi.pia.enums

enum class UserConectionState {
    Conected,
    Absent
}