package com.fcfm.poi.pia.modelos

data class FechaAssignment(
    var anio   : Int = 1 ,
    var mes    : Int = 1 ,
    var dia    : Int = 1 ,
    var hora   : Int = 1 ,
    var minuto : Int = 1
);