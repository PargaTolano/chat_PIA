package com.fcfm.poi.pia.enums

enum class ChatroomType {
    DirectMessage,
    Group
}